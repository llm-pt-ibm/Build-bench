#include "test.h"

TEST(Misc, dummy)
{
    EXPECT_EQ(1, 1);
}
